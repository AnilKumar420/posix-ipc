Overview:
Data exchange between 2 applications using POSIX IPC

App1: It receives data from the Named FIFO Ipc and displays on the console
App2: It sends data periodically(60 messages per second)
Shared-lib: This shared library handles Named FIFO IPC operations

How to build:

Please run the script: build-script.sh

Binaries Path:
App1:ecarx-assignment/using-fifo/Application1/build/app1
App2:ecarx-assignment/using-fifo/Application1/build/app2

How to run:
Open 2 terminals from the above paths
export LD_LIBRARY_PATH=/usr/local/lib/
Run App1 first always, it waits for the data
Run App2
Press Ctrl+c to stop App1
App2 will be stopped, if App1 is killed
