#include <iostream>
#include "shared-lib.h"
#include <sys/mman.h>
#include "Application1.h"

void Application1::openIpc()
{
	if(m_ipcObj != nullptr)
	{
		m_fifoFd = m_ipcObj->openIpcToReadData();
	}
	
}

void Application1::readData()
{
	if(m_ipcObj == nullptr)
	{
		std::cout<<"Ipc obj is null"<<std::endl;
		return;
	}
	while (true) 
	{
		m_bytesRead = m_ipcObj->readIpc(m_fifoFd, &m_receivedData, sizeof(m_receivedData));		

		if (m_bytesRead == sizeof(m_receivedData))
		{
			std::cout << "App1:Received data: " << m_receivedData << std::endl;
		}
		else
		{
			std::cerr << "Error reading data from the FIFO." << std::endl;
			break;
		}
	}
}

void Application1::closeIpc()
{
	if(m_ipcObj != nullptr)
	{
		m_ipcObj->closeIpc(m_fifoFd);
}	}

int main()
{
	std::cout<<"App1 Running"<<std::endl;
	Application1 objApplication1;
	objApplication1.openIpc();
	objApplication1.readData();
	objApplication1.closeIpc();
	return 0;
}

