
class Application1
{
	int m_fifoFd;
	ssize_t m_receivedData;
	ssize_t m_bytesRead;
	MyIpcInterface* m_ipcObj;
public:
	Application1()
	{
		m_fifoFd = 0;
		m_receivedData = 0;
		m_bytesRead = 0;	
		m_ipcObj = new NamedFifoIpc();	
	}
	~Application1()
	{
		delete m_ipcObj;
	}
	void openIpc();
	void readData();
	void closeIpc();
};
