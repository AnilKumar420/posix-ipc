#include "shared-lib.h"
class Application2
{
	int m_fifoFd;
	double m_sum;
	double m_time;
	double m_frequency;
	double m_amplitude;
	MyIpcInterface* m_ipcObj;
	uint16_t processSpeedometerData();
public:
	Application2()
	{
		m_fifoFd = 0;
		m_sum = 0;
		m_time = 0;
		m_frequency = 0;
		m_amplitude = 0;
		m_ipcObj = new NamedFifoIpc();
	}
	~Application2()
	{
		delete m_ipcObj;
	}
	void openIpcWrite();
	void sendData();
	void processDataSin();
	void closeIpc();
};


