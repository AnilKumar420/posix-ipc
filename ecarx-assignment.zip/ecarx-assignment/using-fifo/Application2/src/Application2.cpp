#include <iostream>
#include <cmath>
#include <random>
#include "Application2.h"

void Application2::openIpcWrite()
{
	if(m_ipcObj != nullptr)
	{	
		m_fifoFd = m_ipcObj->openIpcToWriteData();
	}
}

//Not using this for now
void Application2::processDataSin()
{
	srand(static_cast<unsigned>(time(NULL)));	
	// Generate the sum of sines with different periods and coefficients
	m_time = static_cast<double>(clock()) / CLOCKS_PER_SEC;

	// Add multiple sine components with different frequencies and amplitudes
	for (int i = 1; i <= 5; ++i)
	{
		m_frequency = i * 1.0;  // Varying frequencies
		m_amplitude = rand() % 10 + 1; // Random amplitudes
		m_sum += m_amplitude * sin(2 * M_PI * m_frequency * m_time);
	}

}

uint16_t Application2::processSpeedometerData()
{
	std::random_device rd;
	std::mt19937 gen(rd());
	// Define the range for random numbers (0 to 200)
	std::uniform_int_distribution<int> distribution(0, 200);
	ssize_t random_number = distribution(gen);
	return random_number;

}
void Application2::sendData()
{
	if(m_ipcObj == nullptr)
	{
		std::cout<<"Ipc obj is null"<<std::endl;
		return;
	}
	ssize_t data;
	while (true)
	{
		//processDataSin();//Use this for the data generated using sin()
		//m_ipcObj->writeIpc(m_fifoFd,&m_sum, sizeof(m_sum));
		//std::cout << "Sent data: " << m_sum << std::endl;
		//please note if processData() is called, read logic should be changed

		data = processSpeedometerData();
		m_ipcObj->writeIpc(m_fifoFd,&data, sizeof(data));	
		std::cout << "App2:Sent data: " << data << std::endl;	
		usleep(1000000/60); // Sleep to achieve 60 messages per second
	}
}
void Application2::closeIpc()
{
	if(m_ipcObj == nullptr)
	{	
		m_ipcObj->closeIpc(m_fifoFd);
	}
}
int main() 
{
	Application2 objApplication2;
	objApplication2.openIpcWrite();
	objApplication2.sendData();     
	objApplication2.closeIpc();
	return 0;
}

