
#include "shared-lib.h"

extern "C"{
int NamedFifoIpc::openIpcToWriteData()
{
	// Create the FIFO if it doesn't exist
	mkfifo(m_fifoPath.c_str(), 0666);
	int fifo_fd = open(m_fifoPath.c_str(), O_WRONLY);
	if (fifo_fd == -1)
	{
		std::cerr << "Error opening FIFO for writing." << std::endl;
		return EXIT_FAILURE;
	}
	else
	{
		return fifo_fd;
	}
}

int NamedFifoIpc::openIpcToReadData()
{
	// Create the FIFO if it doesn't exist
	mkfifo(m_fifoPath.c_str(), 0666);
	int fifo_fd = open(m_fifoPath.c_str(), O_RDONLY);
	if (fifo_fd == -1)
	{
		std::cerr << "Error opening FIFO for writing." << std::endl;
		return EXIT_FAILURE;
	}
	else
	{
		return fifo_fd;
	}
}
ssize_t NamedFifoIpc::writeIpc(int fd,const void *buf,ssize_t count)
{
	return (write(fd, buf, sizeof(buf)));
}

ssize_t NamedFifoIpc::readIpc(int fd,void *buf,ssize_t count)
{
	return (read(fd,buf,sizeof(buf)));
}
void NamedFifoIpc::closeIpc(int fifoFd)
{
	close(fifoFd);
}

}

