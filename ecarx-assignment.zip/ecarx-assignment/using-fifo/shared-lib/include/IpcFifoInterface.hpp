class MyIpcInterface
{
public:
	virtual int openIpcToWriteData()=0;
	virtual int openIpcToReadData()=0;
	virtual ssize_t writeIpc(int fd,const void *buf,ssize_t count)=0;
	virtual ssize_t readIpc(int fd,void *buf,ssize_t count)=0;
	virtual void closeIpc(int)=0;
};
