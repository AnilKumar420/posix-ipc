#ifndef SHAREDLIB_H
#define SHAREDLIB_H

#include <iostream>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdlib>
#include "IpcFifoInterface.hpp"

class NamedFifoIpc : public MyIpcInterface
{
	const std::string m_fifoPath;
public:
	NamedFifoIpc():m_fifoPath("/tmp/my_fifo")
	{

	}

	int openIpcToWriteData();
	int openIpcToReadData();
	ssize_t writeIpc(int fd,const void *buf,ssize_t count);
	ssize_t readIpc(int fd,void *buf,ssize_t count);
	void closeIpc(int);

};
#endif
