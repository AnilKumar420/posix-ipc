
//Application2 sends 60 messages(integer data) per second via Shared Memory IPC

#include "Application2.h"
#include "SharedMemoryLib.h"


#define SHARED_MEM "/SharedMem"
#define PRODUCER_SEMAPHORE "/ProducerSem"
#define CONSUMER_SEMAPHORE "/ConsumerSem"
#define FRAME_RATE 60

sem_t *sem_producer;
sem_t *sem_consumer;
int *sendData;
MyIpcInterface* ipcObj;

// Signal handler function
void signalHandler(int signal) 
{
	if (signal == SIGINT)
	{
		std::cout << "App2:Ctrl+C signal caught. Exiting gracefully." << std::endl;
		exit(EXIT_SUCCESS);
	}
	if(ipcObj != nullptr)
	{
		ipcObj->destroySemaphore(sem_producer);
		ipcObj->destroySemaphore(sem_consumer);
		ipcObj->destroySharedMemory(SHARED_MEM);
		delete ipcObj;
	}

	std::cout<<"App2:exiting"<<std::endl;
}

//Creates Object to interact with SharedMem interface
//Requests Shared memory interface to create semaphore for synchronization

void initIpc()
{
	ipcObj = new SharedMemoryLib();

	if(ipcObj == nullptr)
	{
		std::cout<<"App2:unable to fetch SharedMem Object"<<std::endl;
		exit(EXIT_FAILURE);
	}

	ipcObj->createSemaphore(&sem_producer,PRODUCER_SEMAPHORE,0);
	ipcObj->createSemaphore(&sem_consumer,CONSUMER_SEMAPHORE,0);

}

//Generates the Random data in the range between 0 to 200
//Sends it over Shared Memory Ipc until the application is terminated

void writeSharedMemData()
{
	//attaching memory
	sendData = ipcObj->attachSharedMemory(SHARED_MEM);
	/* write to the shared memory object */
	while(true)
	{
		ipcObj->waitSemaphore(sem_consumer);
		*sendData = rand() % 200; // Generate random data and write to shared memory
		std::cout << "App2 SendData:"<< *sendData <<std::endl;
		ipcObj->postSemaphore(sem_producer);
		usleep(1000000/FRAME_RATE); // Sleep to achieve 60 messages per second
	}

}
int main()
{
	std::cout<<"App2 Running"<< std::endl;
	// Register the signal handler for SIGINT (Ctrl+C)
	if (signal(SIGINT, signalHandler) == SIG_ERR)
	{
		std::cerr << "Failed to set up the signal handler." << std::endl;
		return EXIT_FAILURE;
	}
	initIpc();
	writeSharedMemData();

	return 0;
}
