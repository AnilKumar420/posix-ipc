#ifndef APP2_H
#define APP2_H

#include <semaphore.h>
#include <iostream>
#include <csignal>

void initIpc();
void writeSharedMemData();

#endif
