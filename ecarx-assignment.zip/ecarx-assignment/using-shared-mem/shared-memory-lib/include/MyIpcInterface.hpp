class MyIpcInterface
{
public:
	virtual bool createSharedMemory(const char* name, size_t size)=0;
	virtual int* attachSharedMemory(const char* name)=0;
	virtual void detachSharedMemory(int* shared_data)=0;
	virtual void destroySharedMemory(const char* sharedMemName)=0;
	virtual void createSemaphore(sem_t** semaphore, const char* name, int value)=0;
	virtual void waitSemaphore(sem_t* semaphore)=0;
	virtual void destroySemaphore(sem_t* semaphore)=0;
	virtual void postSemaphore(sem_t* semaphore)=0;	
	virtual void unlinkSemaphore(const char* name)=0;
};
