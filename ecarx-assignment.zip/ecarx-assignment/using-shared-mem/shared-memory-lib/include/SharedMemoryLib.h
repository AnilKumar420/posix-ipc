#ifndef SHAREDMEMLIB_H
#define SHAREDMEMLIB_H

#include <iostream>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdlib>
#include "MyIpcInterface.hpp"

class SharedMemoryLib : public MyIpcInterface
{

public:

	bool createSharedMemory(const char* name, size_t size);
	int* attachSharedMemory(const char* name);
	void detachSharedMemory(int* shared_data);
	void createSemaphore(sem_t** semaphore, const char* name, int value);
	void waitSemaphore(sem_t* semaphore);
	void destroySemaphore(sem_t* semaphore);
	void postSemaphore(sem_t* semaphore);
	void destroySharedMemory(const char* name);
	void unlinkSemaphore(const char* name);

};
#endif	
