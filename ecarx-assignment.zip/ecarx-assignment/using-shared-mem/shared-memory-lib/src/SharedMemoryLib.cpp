
#include <semaphore.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include "SharedMemoryLib.h"

extern"C"{
bool SharedMemoryLib::createSharedMemory(const char* name, size_t size) {
	int fd = shm_open(name, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
	if (fd == -1) {
		perror("shm_open");
		return false;
	}

	if (ftruncate(fd, size) == -1) {
		perror("ftruncate");
		close(fd);
		return false;
	}

	close(fd);
	return true;
}

int* SharedMemoryLib::attachSharedMemory(const char* name) {
	int fd = shm_open(name, O_RDWR, 0);
	if (fd == -1) {
		perror("shm_open");
		return nullptr;
	}

	int* shared_data = static_cast<int*>(mmap(nullptr, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0));
	if (shared_data == MAP_FAILED) {
		perror("mmap");
		close(fd);
		return nullptr;
	}

	close(fd);
	return shared_data;
}

void SharedMemoryLib::detachSharedMemory(int* shared_data) {
	munmap(shared_data, sizeof(int));
}

void SharedMemoryLib::createSemaphore(sem_t** semaphore, const char* name, int value) {
	*semaphore = sem_open(name, O_CREAT, S_IRUSR | S_IWUSR, value);
	if (*semaphore == SEM_FAILED) {
		perror("sem_open");
		*semaphore = nullptr;
	}
}

void SharedMemoryLib::waitSemaphore(sem_t* semaphore) {
	sem_wait(semaphore);
}

void SharedMemoryLib::postSemaphore(sem_t* semaphore) {
	sem_post(semaphore);
}

void SharedMemoryLib::destroySemaphore(sem_t* semaphore)
{
	sem_close(semaphore);
}
void SharedMemoryLib::destroySharedMemory(const char* sharedMem)
{
	shm_unlink(sharedMem);
}
void SharedMemoryLib::unlinkSemaphore(const char* semName)
{
	sem_unlink(semName);
}
}//extern "C"
