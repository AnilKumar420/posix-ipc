Please follow below instructions to run Application1 and Application2

Application1: It receives data sent by the Application2 and print to the console

Application2: It sends 60 messages per second(integer data) via Shared Memory IPC

SharedMemoryInterface: This shared library deals with Shared memory IPC and Semaphore operations

Build instructions:

Run build-script.sh, this will compile App1, App2 and Shared Memory library.
It installs shared memory library file to /usr/local/lib
It installs shared memory header to /usr/local/include

How to Run:

Binary path: ecarx-assignment/using-shared-mem/Application1/build/app1
	      ecarx-assignment/using-shared-mem/Application2/build/app2
	      
Open 2 terminals one for App1 and another one for App2
export LD_LIBRARY_PATH=/usr/local/lib

Please run App1 first always, then run App2
Once App1 is running, it signals App2 to send the data
App2 will send the data until user terminates the application2

To stop the applications press Ctrl+c. 
