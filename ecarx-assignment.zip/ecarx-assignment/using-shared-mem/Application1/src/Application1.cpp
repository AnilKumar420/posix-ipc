//Application1 receives data from Shared Memory IPC
//This data can be used for further processing like Speedometer display

#include "Application1.h"

sem_t *sem_consumer;
sem_t *sem_producer;
MyIpcInterface *ipcObj;
int *receivedData;

// Signal handler function
void signalHandler(int signal) 
{
	if (signal == SIGINT)
	{
		std::cout << "Ctrl+C signal caught. Exiting gracefully." << std::endl;
		exit(EXIT_SUCCESS);
	}
	if(ipcObj != nullptr)
	{
		ipcObj->destroySemaphore(sem_consumer);
		ipcObj->detachSharedMemory(receivedData);
		ipcObj->destroySharedMemory(SHARED_MEM);
		delete ipcObj;
	}

	std::cout<<"App1 exiting"<<std::endl;
}

void initIpc()
{
	bool sharedMemStatus = false;
	ipcObj = new SharedMemoryLib();
	if(ipcObj == nullptr)
	{
		exit(EXIT_FAILURE);
	}
	ipcObj->unlinkSemaphore(PRODUCER_SEMAPHORE);
	ipcObj->unlinkSemaphore(CONSUMER_SEMAPHORE);
	ipcObj->createSemaphore(&sem_producer,PRODUCER_SEMAPHORE,0);
	ipcObj->createSemaphore(&sem_consumer,CONSUMER_SEMAPHORE,1);		
	sharedMemStatus = ipcObj->createSharedMemory(SHARED_MEM,SIZE);	
	if(sharedMemStatus == false)
	{
		std::cout<<"App1: Could not create shared memory"<<std::endl;
		std::cout<<"App1:Exiting"<<std::endl;
		exit(EXIT_FAILURE);
	}
}

void readSharedMemData()
{
	receivedData = ipcObj->attachSharedMemory(SHARED_MEM);
	/* read from the shared memory object */
	while(1)
	{
		ipcObj->waitSemaphore(sem_producer);
		//This data can be used to display speed on speedometer
		printf("App1 Received Data:%d\n", *receivedData);
		ipcObj->postSemaphore(sem_consumer);
	}
}

int main()
{
	std::cout<<"App1 Running"<< std::endl;
	// Register the signal handler for SIGINT (Ctrl+C)
	if (signal(SIGINT, signalHandler) == SIG_ERR)
	{
		std::cerr << "App1:Failed to set up the signal handler." << std::endl;
		return EXIT_FAILURE;
	}
	initIpc();
	readSharedMemData();
	return 0;
}
