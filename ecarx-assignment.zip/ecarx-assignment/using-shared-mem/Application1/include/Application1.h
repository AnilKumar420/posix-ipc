#ifndef APP1_H
#define APP1_H

#include<stdio.h>
#include <semaphore.h>
#include <csignal>
#include "SharedMemoryLib.h"

#define SHARED_MEM "/SharedMem"
#define PRODUCER_SEMAPHORE "/ProducerSem"
#define CONSUMER_SEMAPHORE "/ConsumerSem"
#define SIZE sizeof(int)

void initIpc();
void readSharedMemData();
#endif


