#!/bin/bash

# Specify the directory name you want to create
directory_name="build"


    # Create the directory
    cd shared-memory-lib
    mkdir "$directory_name"
    if [ $? -eq 0 ]; then
        echo "Directory '$directory_name' created successfully."
    else
        echo "Failed to create directory '$directory_name'."
    fi
    cd "$directory_name"
    cmake ..
    make
    sudo make install
    cd ../../
    
    # Create the directory
    cd Application1
    mkdir "$directory_name"
    if [ $? -eq 0 ]; then
        echo "Directory '$directory_name' created successfully."
    else
        echo "Failed to create directory '$directory_name'."
    fi
    cd "$directory_name"
    cmake ..
    make   
    cd ../../

	cd Application2
	mkdir "$directory_name"
    if [ $? -eq 0 ]; then
        echo "Directory '$directory_name' created successfully."
    else
        echo "Failed to create directory '$directory_name'."
    fi
    cd "$directory_name"
    cmake ..
    make
    cd ../../




